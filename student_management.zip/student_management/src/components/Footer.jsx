import React from "react";

function Footer() {
  return <div>AUCA @ 2025</div>;
}

export default Footer;
